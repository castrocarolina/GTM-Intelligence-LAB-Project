# GTM Intelligence Lab — Web App

Interactive dashboard showing how customer data becomes go-to-market decisions: KPIs, RFM/K-means segments, GTM briefs per segment, and a budget reallocation simulator.

Companion to the analysis pipeline: https://github.com/castrocarolina/GTM-Intelligence-LAB-Project

> Channel spend is **simulated**. CAC, ROAS and payback are scenario-based planning metrics, not observed ad-platform data.

## Pages
- **Overview** — revenue, AOV, repeat rate, ROAS, payback
- **Segments** — size vs. LTV chart and segment profiles
- **GTM Brief** — persona, pain, value proposition, messages, channel, objections, A/B tests
- **Simulator** — move budget between channels and see estimated revenue/LTV impact
- **About** — problem, approach, limitations

## Run locally
Requires Node.js 20+.
```sh
npm install
npm run dev
```
Tests: `npx vitest run`

## Updating the data
Replace the files in `src/data/` (`segments.json`, `kpis.json`, `briefs.json`, `simulator.json`) with new output from `python -m src.export_for_web`. No code changes needed; `src/lib/data-consistency.test.ts` checks the export reconciles.

## Publish to GitHub
```sh
git init
git add .
git commit -m "GTM Intelligence Lab web app"
git branch -M main
git remote add origin https://github.com/castrocarolina/<new-repo-name>.git
git push -u origin main
```

## Stack
React 19, TanStack Start, Vite, Tailwind CSS v4, Recharts.
