import { createFileRoute, Link } from "@tanstack/react-router";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { ArrowRight } from "lucide-react";
import { channelLabel, customersWithoutOrders, kpis, segments, totalCustomers, totalSpend } from "@/lib/data";
import { money, num, pct } from "@/lib/format";
import { ChartTip, Kpi, PageHeader, Panel, SimBadge, SimulatedNotice, axisProps, chartColors } from "@/components/lab/ui";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Overview · GTM Intelligence Lab" },
      { name: "description", content: "Revenue, average order value, repeat rate, ROAS and payback from customer transaction data." },
      { property: "og:title", content: "Overview · GTM Intelligence Lab" },
      { property: "og:description", content: "Core e-commerce KPIs and simulated channel efficiency in one view." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Overview,
});

function Overview() {
  const hasNewCustomers = kpis.channel_kpis.some((c) => c.attributed_new_customers_simulated !== undefined);
  const headers = ["Channel", "Spend", "Attributed orders", ...(hasNewCustomers ? ["New customers"] : []), "Est. revenue", "CAC", "ROAS", "Payback"];
  const channels = [...kpis.channel_kpis]
    .sort((a, b) => b.spend - a.spend)
    .map((c) => ({ ...c, label: channelLabel(c.channel) }));
  const segRevenue = [...segments].sort((a, b) => b.historical_revenue - a.historical_revenue);

  return (
    <>
      <PageHeader
        eyebrow="Overview"
        title="From transactions to GTM decisions"
        description={`${num(totalCustomers)} purchasing customers in ${segments.length} segments${customersWithoutOrders ? ` (plus ${num(customersWithoutOrders)} registered without orders)` : ""}, summarized into the numbers that drive channel and message choices.`}
      />

      <SimulatedNotice />

      <div className="mt-6 grid grid-cols-2 gap-3 md:grid-cols-3">
        <Kpi label="Revenue" value={money(kpis.revenue_total, { compact: true })} hint="Lifetime, all customers" />
        <Kpi label="Avg. order value" value={money(kpis.average_order_value)} hint="Revenue / orders" />
        <Kpi label="Repeat rate" value={pct(kpis.repeat_purchase_rate)} hint="Customers with 2+ orders" />
        <Kpi label="CAC" value={money(kpis.cac_overall)} hint="Total spend / purchasing customers" simulated />
        <Kpi label="ROAS" value={`${kpis.roas_overall.toFixed(2)}×`} hint="Revenue / total spend" simulated />
        <Kpi
          label="Payback"
          value={`${num(kpis.payback_months_overall_estimated, { digits: 1 })} mo`}
          hint={`At ${pct(kpis.gross_margin_assumption, 0)} gross margin`}
          simulated
        />
      </div>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Panel
          className="lg:col-span-3"
          title="Spend vs. estimated revenue by channel"
          subtitle={`Total simulated spend ${money(totalSpend, { compact: true })}`}
          right={<SimBadge />}
        >
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={channels} margin={{ left: 0, right: 8 }}>
                <CartesianGrid vertical={false} stroke="var(--border)" />
                <XAxis dataKey="label" {...axisProps} interval={0} />
                <YAxis {...axisProps} width={56} tickFormatter={(v) => money(v, { compact: true })} />
                <Tooltip
                  cursor={{ fill: "var(--muted)" }}
                  content={({ payload }) => {
                    const c = payload?.[0]?.payload as (typeof channels)[number] | undefined;
                    if (!c) return null;
                    return (
                      <ChartTip
                        lines={[
                          { label: c.label, value: "" },
                          { label: "Spend", value: money(c.spend, { compact: true }) },
                          { label: "Est. revenue", value: money(c.estimated_attributed_revenue, { compact: true }) },
                          { label: "ROAS", value: `${c.roas_estimated.toFixed(2)}×` },
                        ]}
                      />
                    );
                  }}
                />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                <Bar name="Spend" dataKey="spend" fill="var(--chart-3)" fillOpacity={0.4} radius={[3, 3, 0, 0]} />
                <Bar name="Est. revenue" dataKey="estimated_attributed_revenue" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </Panel>

        <Panel className="lg:col-span-2" title="Revenue by segment" subtitle="Historical, from RFM clusters">
          <ul className="space-y-4">
            {segRevenue.map((s) => {
              const i = segments.findIndex((x) => x.name === s.name);
              const share = kpis.revenue_total > 0 ? s.historical_revenue / kpis.revenue_total : 0;
              return (
                <li key={s.name}>
                  <div className="flex items-baseline justify-between text-sm">
                    <span className="font-medium">{s.name}</span>
                    <span className="num text-muted-foreground">{money(s.historical_revenue, { compact: true })}</span>
                  </div>
                  <div className="mt-1.5 h-2 rounded-full bg-muted">
                    <div className="h-2 rounded-full" style={{ width: `${share * 100}%`, background: chartColors[i % 5] }} />
                  </div>
                </li>
              );
            })}
          </ul>
          <Link to="/segments" className="mt-5 inline-flex items-center gap-1 text-sm font-medium text-primary hover:underline">
            Explore segments <ArrowRight className="size-3.5" />
          </Link>
        </Panel>
      </div>

      <Panel className="mt-6" title="Channel economics" subtitle="Planning metrics per channel" right={<SimBadge />}>
        <div className="-mx-5 overflow-x-auto">
          <table className="w-full min-w-[640px] text-sm">
            <thead>
              <tr className="border-b text-left">
                {headers.map((h, i) => (
                  <th key={h} className={`eyebrow px-5 py-2 font-semibold ${i > 0 ? "text-right" : ""}`}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {channels.map((c) => (
                <tr key={c.channel} className="border-b last:border-0">
                  <td className="px-5 py-2.5 font-medium">{c.label}</td>
                  <td className="num px-5 py-2.5 text-right">{money(c.spend, { compact: true })}</td>
                  <td className="num px-5 py-2.5 text-right">{num(c.attributed_orders_simulated)}</td>
                  {hasNewCustomers && (
                    <td className="num px-5 py-2.5 text-right">{num(c.attributed_new_customers_simulated ?? 0)}</td>
                  )}
                  <td className="num px-5 py-2.5 text-right">{money(c.estimated_attributed_revenue, { compact: true })}</td>
                  <td className="num px-5 py-2.5 text-right">{money(c.cac)}</td>
                  <td className="num px-5 py-2.5 text-right">{c.roas_estimated.toFixed(2)}×</td>
                  <td className="num px-5 py-2.5 text-right">{c.payback_months_estimated.toFixed(1)} mo</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {kpis.limitations && <p className="mt-4 text-xs text-muted-foreground">{kpis.limitations}</p>}
      </Panel>
    </>
  );
}
