import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { ArrowRight, RotateCcw } from "lucide-react";
import { Bar, BarChart, CartesianGrid, Legend, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { channelLabel, kpis, segments, simulator, totalSpend } from "@/lib/data";
import { money, pct } from "@/lib/format";
import { LTV_SCALE, MULTIPLIER_FLOOR, REVENUE_SCALE, simulateMove } from "@/lib/simulator";
import { ChartTip, PageHeader, Panel, SimulatedNotice, axisProps } from "@/components/lab/ui";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/simulator")({
  head: () => ({
    meta: [
      { title: "Budget Simulator · GTM Intelligence Lab" },
      { name: "description", content: "Move budget between channels and see the estimated impact on revenue and customer LTV." },
      { property: "og:title", content: "Budget Simulator · GTM Intelligence Lab" },
      { property: "og:description", content: "A transparent scenario model for channel reallocation." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: SimulatorPage,
});

const budgets = Object.fromEntries(kpis.channel_kpis.map((c) => [c.channel, c.spend]));
const channelKeys = Object.keys(simulator.channel_efficiency_assumptions);
const efficiency = simulator.channel_efficiency_assumptions;
const simSegments = segments.filter((s) => simulator.segment_channel_affinity_assumptions[s.name]);
const bySpend = [...kpis.channel_kpis].sort((a, b) => b.spend - a.spend);
const byEff = [...channelKeys].sort((a, b) => (efficiency[b] ?? 0) - (efficiency[a] ?? 0));

const defaults = {
  segment: simSegments[0]?.name ?? "",
  source: bySpend[0]?.channel ?? channelKeys[0] ?? "",
  target: byEff.find((c) => c !== bySpend[0]?.channel) ?? channelKeys[1] ?? "",
  pct: 20,
};

const formulaLabels: Record<string, string> = {
  amount_moved: "Amount moved",
  source_budget_after: "Source budget after",
  target_budget_after: "Target budget after",
  revenue_multiplier: "Revenue multiplier",
  estimated_revenue_delta: "Estimated revenue change",
  estimated_ltv_delta: "Estimated LTV change",
};

function SimulatorPage() {
  const [segmentName, setSegmentName] = useState(defaults.segment);
  const [source, setSource] = useState(defaults.source);
  const [target, setTarget] = useState(defaults.target);
  const [share, setShare] = useState(defaults.pct);

  const segment = simSegments.find((s) => s.name === segmentName) ?? simSegments[0];
  const result = useMemo(
    () => (segment ? simulateMove(simulator, segment, budgets, { segment: segment.name, source, target, pct: share / 100 }) : null),
    [segment, source, target, share],
  );

  const reset = () => {
    setSegmentName(defaults.segment);
    setSource(defaults.source);
    setTarget(defaults.target);
    setShare(defaults.pct);
  };

  if (!segment || !result) return <p className="text-sm text-muted-foreground">No simulator data available.</p>;

  const affinity = simulator.segment_channel_affinity_assumptions[segment.name] ?? {};
  const capped = result.revenueMultiplier < MULTIPLIER_FLOOR;
  const chartData = result.budgets.map((b) => ({ channel: channelLabel(b.channel), Before: b.before, After: b.after }));

  return (
    <>
      <PageHeader
        eyebrow="Simulator"
        title="Budget reallocation"
        description={`Move a share of one channel's budget into another. The ${money(totalSpend, { compact: true })} total stays fixed.`}
        actions={
          <Button variant="outline" size="sm" onClick={reset}>
            <RotateCcw className="size-3.5" /> Reset
          </Button>
        }
      />

      <SimulatedNotice>
        <strong className="font-semibold">Scenario model, not a causal estimate.</strong> Budgets are simulated and
        efficiency, affinity and scaling values are fixed assumptions. Use it to compare directions, not to set targets.
      </SimulatedNotice>

      <div className="mt-6 grid gap-6 lg:grid-cols-5">
        <Panel className="lg:col-span-2" title="Move budget">
          <div className="space-y-4">
            <Field label="Target segment">
              <Select value={segment.name} onValueChange={setSegmentName}>
                <SelectTrigger aria-label="Target segment"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {simSegments.map((s) => (
                    <SelectItem key={s.name} value={s.name}>{s.name}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </Field>

            <div className="grid grid-cols-[1fr_auto_1fr] items-end gap-2">
              <Field label="From">
                <ChannelSelect value={source} onChange={setSource} exclude={target} label="From channel" />
              </Field>
              <ArrowRight className="mb-2.5 size-4 text-muted-foreground" />
              <Field label="To">
                <ChannelSelect value={target} onChange={setTarget} exclude={source} label="To channel" />
              </Field>
            </div>

            <div className="rounded-md bg-muted p-4">
              <div className="mb-3 flex items-baseline justify-between">
                <span className="text-sm font-medium">Share of {channelLabel(source)} budget</span>
                <span className="num text-lg font-semibold">{share}%</span>
              </div>
              <Slider
                aria-label="Share of source budget to move"
                min={0}
                max={100}
                step={1}
                value={[share]}
                onValueChange={([v]) => setShare(v ?? 0)}
              />
              <div className="num mt-2 flex justify-between text-xs text-muted-foreground">
                <span>0%</span>
                <span>{money(result.amountMoved, { compact: true })} moved</span>
                <span>100%</span>
              </div>
            </div>

            <dl className="grid grid-cols-2 gap-3 text-sm">
              <ChannelFact label={channelLabel(source)} eff={efficiency[source] ?? 0} aff={affinity[source] ?? 0} />
              <ChannelFact label={channelLabel(target)} eff={efficiency[target] ?? 0} aff={affinity[target] ?? 0} />
            </dl>
          </div>
        </Panel>

        <div className="grid content-start gap-6 lg:col-span-3">
          <div className="grid grid-cols-2 gap-3">
            <Result
              label="Est. revenue change"
              value={money(result.revenueDelta, { compact: Math.abs(result.revenueDelta) >= 10000 })}
              tone={result.revenueDelta}
              hint={
                segment.historical_revenue > 0
                  ? `${pct(result.revenueDelta / segment.historical_revenue)} of segment revenue`
                  : "Segment has no historical revenue"
              }
            />
            <Result
              label="Est. LTV change"
              value={money(result.ltvDelta)}
              tone={result.ltvDelta}
              hint={
                segment.total_predicted_ltv > 0
                  ? `${pct(result.ltvDelta / segment.total_predicted_ltv)} of segment LTV`
                  : "Segment has no predicted LTV"
              }
            />
            <Result label="Amount moved" value={money(result.amountMoved, { compact: true })} hint={`${pct(result.amountMoved / totalSpend)} of total budget`} />
            <Result
              label="Revenue multiplier"
              value={result.revenueMultiplier.toFixed(3)}
              tone={result.revenueMultiplier}
              hint={capped ? `Capped at ${MULTIPLIER_FLOOR} in the estimate` : "Target fit minus source fit"}
            />
          </div>

          <Panel title="Channel budgets" subtitle="Before vs. after the move">
            <div className="h-60">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chartData} margin={{ left: 0, right: 8 }}>
                  <CartesianGrid vertical={false} stroke="var(--border)" />
                  <XAxis dataKey="channel" {...axisProps} interval={0} />
                  <YAxis {...axisProps} width={56} tickFormatter={(v) => money(v, { compact: true })} />
                  <Tooltip
                    cursor={{ fill: "var(--muted)" }}
                    content={({ payload, label }) =>
                      payload?.length ? (
                        <ChartTip
                          lines={[
                            { label: String(label), value: "" },
                            ...payload.map((p) => ({ label: String(p.name), value: money(Number(p.value), { compact: true }) })),
                          ]}
                        />
                      ) : null
                    }
                  />
                  <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 12 }} />
                  <Bar dataKey="Before" fill="var(--chart-3)" fillOpacity={0.35} radius={[3, 3, 0, 0]} />
                  <Bar dataKey="After" fill="var(--chart-1)" radius={[3, 3, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </Panel>
        </div>
      </div>

      <h2 className="mt-10 mb-1 text-lg font-semibold">Assumptions</h2>
      <p className="mb-4 max-w-3xl text-sm text-muted-foreground">{simulator.formula_explanation}</p>

      <div className="grid gap-4 lg:grid-cols-3">
        <Panel className="lg:col-span-2" title="Formulas">
          <ul className="divide-y">
            {Object.entries(simulator.formula).map(([key, expr]) => (
              <li key={key} className="py-3 first:pt-0 last:pb-0">
                <p className="text-sm font-medium">{formulaLabels[key] ?? key.replace(/_/g, " ")}</p>
                <code className="num mt-1 block overflow-x-auto rounded bg-muted px-2 py-1 text-xs">{expr}</code>
              </li>
            ))}
          </ul>
          <p className="mt-4 text-xs text-muted-foreground">
            Scaling factors: revenue × {REVENUE_SCALE}, LTV × {LTV_SCALE}, multiplier floor {MULTIPLIER_FLOOR}.
          </p>
        </Panel>
        <div className="grid content-start gap-4">
          <Panel title="Channel efficiency">
            <table className="w-full text-xs">
              <thead>
                <tr className="text-left">
                  <th className="eyebrow pb-2">Channel</th>
                  <th className="eyebrow pb-2 text-right">Efficiency</th>
                  <th className="eyebrow pb-2 text-right">Budget</th>
                </tr>
              </thead>
              <tbody>
                {byEff.map((c) => (
                  <tr key={c} className="border-t">
                    <td className="py-1.5">{channelLabel(c)}</td>
                    <td className="num py-1.5 text-right">{(efficiency[c] ?? 0).toFixed(2)}</td>
                    <td className="num py-1.5 text-right">{money(budgets[c] ?? 0, { compact: true })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </Panel>
          <Panel title="Limitations">
            <ul className="space-y-2 text-xs text-muted-foreground">
              {simulator.limitations.map((l) => (
                <li key={l} className="flex gap-2">
                  <span className="mt-1.5 size-1 shrink-0 rounded-full bg-warning" />
                  {l}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>

      <Panel className="mt-4" title="Segment–channel affinity" subtitle="Above 1 = the channel reaches this segment better than average.">
        <div className="-mx-5 overflow-x-auto">
          <table className="w-full min-w-[560px] text-sm">
            <thead>
              <tr className="border-b text-left">
                <th className="eyebrow px-5 py-2">Segment</th>
                {byEff.map((c) => (
                  <th key={c} className="eyebrow px-3 py-2 text-center">{channelLabel(c)}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {simSegments.map(({ name }) => {
                const row = simulator.segment_channel_affinity_assumptions[name] ?? {};
                return (
                  <tr key={name} className={cn("border-b last:border-0", name === segment.name && "bg-accent")}>
                    <td className="px-5 py-2 font-medium">{name}</td>
                    {byEff.map((c) => {
                      const a = row[c] ?? 0;
                      return (
                        <td key={c} className="px-3 py-2 text-center">
                          <span
                            className="num inline-block min-w-11 rounded px-1.5 py-0.5 text-xs"
                            style={{ background: `color-mix(in oklab, var(--chart-1) ${Math.round(Math.max(0, a - 0.6) * 60)}%, transparent)` }}
                          >
                            {a.toFixed(2)}
                          </span>
                        </td>
                      );
                    })}
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </Panel>
    </>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div>
      <p className="eyebrow mb-1.5">{label}</p>
      {children}
    </div>
  );
}

function ChannelSelect({ value, onChange, exclude, label }: { value: string; onChange: (v: string) => void; exclude: string; label: string }) {
  return (
    <Select value={value} onValueChange={onChange}>
      <SelectTrigger aria-label={label}><SelectValue /></SelectTrigger>
      <SelectContent>
        {channelKeys.filter((c) => c !== exclude).map((c) => (
          <SelectItem key={c} value={c}>{channelLabel(c)}</SelectItem>
        ))}
      </SelectContent>
    </Select>
  );
}

function ChannelFact({ label, eff, aff }: { label: string; eff: number; aff: number }) {
  return (
    <div className="rounded-md border p-3">
      <dt className="eyebrow">{label}</dt>
      <dd className="num mt-1 text-xs text-muted-foreground">
        efficiency {eff.toFixed(2)} · affinity {aff.toFixed(2)}
        <span className="mt-0.5 block font-semibold text-foreground">fit {(eff * aff).toFixed(3)}</span>
      </dd>
    </div>
  );
}

function Result({ label, value, hint, tone }: { label: string; value: string; hint?: string; tone?: number }) {
  return (
    <div className="panel p-4">
      <p className="eyebrow">{label}</p>
      <p
        className={cn(
          "num mt-2 text-xl font-semibold",
          tone !== undefined && tone > 0 && "text-positive",
          tone !== undefined && tone < 0 && "text-negative",
        )}
      >
        {tone !== undefined && tone > 0 ? "+" : ""}
        {value}
      </p>
      {hint && <p className="mt-0.5 text-[11px] text-muted-foreground">{hint}</p>}
    </div>
  );
}
