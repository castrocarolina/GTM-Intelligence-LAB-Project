import { createFileRoute, Link } from "@tanstack/react-router";
import { CartesianGrid, Cell, LabelList, ResponsiveContainer, Scatter, ScatterChart, Tooltip, XAxis, YAxis, ZAxis } from "recharts";
import { ArrowRight } from "lucide-react";
import { customersWithoutOrders, hasNoOrders, segments, segmentsData, slugify } from "@/lib/data";
import { money, num } from "@/lib/format";
import { ChartTip, PageHeader, Panel, axisProps, chartColors } from "@/components/lab/ui";

export const Route = createFileRoute("/segments")({
  head: () => ({
    meta: [
      { title: "Segments · GTM Intelligence Lab" },
      { name: "description", content: "RFM + K-means customer segments compared by size and estimated lifetime value." },
      { property: "og:title", content: "Segments · GTM Intelligence Lab" },
      { property: "og:description", content: "Which customer groups are biggest, and which are most valuable." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Segments,
});

function Segments() {
  const data = segments.map((s, i) => ({
    ...s,
    x: s.customer_share_percent,
    y: s.average_predicted_ltv,
    z: Math.max(s.total_predicted_ltv, 1),
    color: chartColors[i % 5],
  }));

  const maxLtv = Math.max(...segments.map((s) => s.average_predicted_ltv), 1) * 1.15;
  const step = [10, 25, 50, 100, 250, 500, 1000, 2500].find((st) => st * 4 >= maxLtv) ?? 5000;
  const maxShare = Math.max(...segments.map((s) => s.customer_share_percent), 10);
  const xMax = Math.min(100, Math.ceil((maxShare * 1.25) / 10) * 10);
  const xTicks = Array.from({ length: xMax / 10 + 1 }, (_, i) => i * 10);
  const yTicks = Array.from({ length: Math.ceil(maxLtv / step) + 1 }, (_, i) => i * step);

  return (
    <>
      <PageHeader
        eyebrow="Segments"
        title="Size vs. value"
        description={
          <>
            {segments.length} clusters from RFM features with K-means, with K chosen by elbow and silhouette diagnostics
            {segmentsData.k_selection?.silhouette !== undefined && ` (silhouette ${segmentsData.k_selection.silhouette.toFixed(2)})`}.
            {customersWithoutOrders > 0 &&
              ` ${num(customersWithoutOrders)} registered customers without orders are left out, since they have no purchase behavior to cluster.`}
          </>
        }
      />

      <Panel title="Segment map" subtitle="Share of customers vs. average predicted LTV. Bubble size = total predicted LTV.">
        <div className="h-80 sm:h-96">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart margin={{ top: 28, right: 32, bottom: 24, left: 8 }}>
              <CartesianGrid stroke="var(--border)" />
              <XAxis
                type="number"
                dataKey="x"
                name="Share"
                unit="%"
                domain={[0, xMax]}
                ticks={xTicks}
                {...axisProps}
                label={{ value: "Share of customers", position: "insideBottom", offset: -12, fontSize: 11, fill: "var(--muted-foreground)" }}
              />
              <YAxis
                type="number"
                dataKey="y"
                name="Avg LTV"
                domain={[0, yTicks[yTicks.length - 1] ?? step]}
                ticks={yTicks}
                tickFormatter={(v) => money(v, { compact: true })}
                {...axisProps}
                width={64}
              />
              <ZAxis type="number" dataKey="z" range={[250, 2200]} />
              <Tooltip
                cursor={{ strokeDasharray: "3 3" }}
                content={({ payload }) => {
                  const s = payload?.[0]?.payload as (typeof data)[number] | undefined;
                  if (!s) return null;
                  return (
                    <ChartTip
                      lines={[
                        { label: s.name, value: "" },
                        { label: "Customers", value: `${num(s.customer_count)} (${s.customer_share_percent.toFixed(1)}%)` },
                        { label: "Avg LTV", value: money(s.average_predicted_ltv) },
                        { label: "Total LTV", value: money(s.total_predicted_ltv, { compact: true }) },
                      ]}
                    />
                  );
                }}
              />
              <Scatter data={data}>
                {data.map((d) => (
                  <Cell key={d.name} fill={d.color} fillOpacity={0.75} stroke={d.color} />
                ))}
                <LabelList dataKey="name" position="top" offset={14} fontSize={11} fill="var(--foreground)" />
              </Scatter>
            </ScatterChart>
          </ResponsiveContainer>
        </div>
      </Panel>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        {data.map((s) => {
          const noOrders = hasNoOrders(s);
          const rfm = s.average_rfm;
          return (
            <article key={s.name} className="panel flex flex-col p-5">
              <div className="flex items-center gap-2">
                <span className="size-2.5 rounded-full" style={{ background: s.color }} />
                <h3 className="font-semibold">{s.name}</h3>
                <span className="num ml-auto text-xs text-muted-foreground">{s.customer_share_percent.toFixed(1)}% of customers</span>
              </div>
              <p className="mt-2 text-sm text-muted-foreground">{s.description.split(" Observed averages")[0]}</p>

              <dl className="mt-4 grid grid-cols-3 gap-3 rounded-md bg-muted p-3">
                <Stat label="Recency" value={noOrders ? "No orders" : `${num(rfm.recency_days)}d`} />
                <Stat label="Frequency" value={rfm.frequency_orders.toFixed(2)} />
                <Stat label="Monetary" value={money(rfm.monetary_revenue_per_order)} />
              </dl>
              <dl className="mt-3 grid grid-cols-2 gap-3 px-3 sm:grid-cols-4">
                <Stat label="Customers" value={num(s.customer_count)} />
                <Stat label="Revenue" value={money(s.historical_revenue, { compact: true })} />
                <Stat label="Avg LTV" value={money(s.average_predicted_ltv)} />
                <Stat label="Total LTV" value={money(s.total_predicted_ltv, { compact: true })} />
              </dl>
              {noOrders && (
                <p className="mt-3 px-3 text-xs text-muted-foreground">
                  No completed orders in the data for this group, so recency and value show as empty.
                </p>
              )}

              <Link
                to="/brief"
                search={{ segment: slugify(s.name) }}
                className="mt-4 inline-flex items-center gap-1 self-start text-sm font-medium text-primary hover:underline"
              >
                View GTM brief <ArrowRight className="size-3.5" />
              </Link>
            </article>
          );
        })}
      </div>
    </>
  );
}

function Stat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <dt className="eyebrow">{label}</dt>
      <dd className="num mt-1 text-sm font-semibold">{value}</dd>
    </div>
  );
}
