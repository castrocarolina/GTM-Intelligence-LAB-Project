import { createFileRoute } from "@tanstack/react-router";
import { ArrowUpRight, Database, FlaskConical, LineChart, Megaphone } from "lucide-react";
import { site } from "@/config/site";
import { PageHeader, Panel } from "@/components/lab/ui";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About · GTM Intelligence Lab" },
      { name: "description", content: "The problem, approach, limitations and source code behind GTM Intelligence Lab." },
      { property: "og:title", content: "About · GTM Intelligence Lab" },
      { property: "og:description", content: "A portfolio project combining marketing analytics, data science and product marketing." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: About,
});

const questions = [
  "Which customer groups are most valuable?",
  "Which segments respond best to which channels?",
  "How should budget split between acquisition and retention?",
  "What message fits each segment?",
];

const layers = [
  { icon: Database, title: "Data foundation", text: "Olist-like transactions (or a deterministic synthetic sample) aggregated into one clean row per customer." },
  { icon: LineChart, title: "Business analytics", text: "Revenue, AOV, repeat rate, CAC, ROAS and payback. Media spend is a simulated planning input." },
  { icon: FlaskConical, title: "Data science", text: "RFM features, K-means clustering with K chosen by elbow + silhouette, and a transparent segment-level LTV." },
  { icon: Megaphone, title: "Product marketing", text: "GTM brief per segment (Anthropic when a key is set, local fallback otherwise) and a channel reallocation simulator." },
];

const limitations = [
  "Marketing spend is simulated, not pulled from real ad platforms.",
  "CAC, ROAS and payback are scenario-based planning metrics.",
  "LTV is simple and explainable, not a full probabilistic lifetime model (e.g. BG/NBD + Gamma-Gamma).",
  "GTM briefs are strategic drafts and need review by a marketer or PM.",
  "Segments are statistical groupings and don't replace business judgment.",
  "The simulator ignores cross-channel effects, saturation and incrementality.",
];

function About() {
  return (
    <>
      <PageHeader
        eyebrow="About"
        title="Why this exists"
        description="A portfolio project combining marketing analytics, marketing data science and product marketing to estimate customer value, segment behavior and propose go-to-market moves."
      />

      <div className="grid gap-6 lg:grid-cols-2">
        <Panel title="The problem">
          <p className="text-sm text-muted-foreground">
            Most e-commerce teams have transaction data but struggle to connect it to channel allocation, customer
            value and positioning. The real question isn't just "who bought?" but:
          </p>
          <ul className="mt-3 space-y-2 text-sm">
            {questions.map((q, i) => (
              <li key={q} className="flex gap-3">
                <span className="num text-xs font-semibold text-primary">0{i + 1}</span>
                {q}
              </li>
            ))}
          </ul>
        </Panel>

        <Panel title="Limitations">
          <ul className="space-y-2 text-sm">
            {limitations.map((l) => (
              <li key={l} className="flex gap-2 text-muted-foreground">
                <span className="mt-2 size-1 shrink-0 rounded-full bg-warning" />
                {l}
              </li>
            ))}
          </ul>
        </Panel>
      </div>

      <h2 className="mt-10 mb-4 text-lg font-semibold">The approach</h2>
      <ol className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {layers.map((l, i) => (
          <li key={l.title} className="panel p-5">
            <div className="flex items-center justify-between">
              <span className="grid size-8 place-items-center rounded-md bg-accent text-accent-foreground">
                <l.icon className="size-4" />
              </span>
              <span className="num text-xs text-muted-foreground">Layer {i + 1}</span>
            </div>
            <h3 className="mt-4 font-semibold">{l.title}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{l.text}</p>
          </li>
        ))}
      </ol>

      <Panel className="mt-10" title="Source code">
        <p className="text-sm text-muted-foreground">
          Python pipeline (Streamlit app, tests, decision log) and the static JSON export that powers this site.
        </p>
        <div className="mt-4 flex flex-wrap gap-3">
          <a
            href={site.githubRepo}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 rounded-md bg-primary px-4 py-2 text-sm font-medium text-primary-foreground hover:bg-primary/90"
          >
            View repository <ArrowUpRight className="size-4" />
          </a>
          <a
            href={`${site.githubRepo}/blob/main/docs/decisions.md`}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 rounded-md border bg-card px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            Technical decisions <ArrowUpRight className="size-4" />
          </a>
          <a
            href={site.githubProfile}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-1.5 rounded-md border bg-card px-4 py-2 text-sm font-medium hover:bg-accent"
          >
            GitHub profile <ArrowUpRight className="size-4" />
          </a>
        </div>
      </Panel>
    </>
  );
}
