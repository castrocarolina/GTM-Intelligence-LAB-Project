import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { FlaskConical, Megaphone, MessageSquareQuote, ShieldQuestion, Target, User, Zap } from "lucide-react";
import type { ReactNode } from "react";
import { briefs, briefsData, channelLabel, segments, slugify } from "@/lib/data";
import { money } from "@/lib/format";
import { PageHeader, Panel, chartColors } from "@/components/lab/ui";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/brief")({
  validateSearch: (search: Record<string, unknown>): { segment?: string | undefined } => ({
    segment: typeof search["segment"] === "string" ? search["segment"] : undefined,
  }),
  head: () => ({
    meta: [
      { title: "GTM Brief · GTM Intelligence Lab" },
      { name: "description", content: "Per-segment go-to-market brief: persona, pain, value proposition, messages, channel, objections and A/B tests." },
      { property: "og:title", content: "GTM Brief · GTM Intelligence Lab" },
      { property: "og:description", content: "Turn a customer segment into a ready-to-review GTM brief." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: BriefPage,
});

function BriefPage() {
  const { segment } = Route.useSearch();
  const navigate = useNavigate({ from: "/brief" });
  const brief = briefs.find((b) => slugify(b.segment_name) === segment) ?? briefs[0];
  if (!brief) return <p className="text-sm text-muted-foreground">No briefs available.</p>;
  const seg = segments.find((s) => s.name === brief.segment_name);
  const segIndex = Math.max(0, segments.findIndex((s) => s.name === brief.segment_name));

  return (
    <>
      <PageHeader
        eyebrow="GTM Brief"
        title="Segment brief"
        description="Pick a segment to see who they are, what to say and where to say it."
      />

      <div role="tablist" aria-label="Segment" className="mb-6 flex flex-wrap gap-2">
        {briefs.map((b) => {
          const active = b.segment_name === brief.segment_name;
          return (
            <button
              key={b.segment_name}
              role="tab"
              aria-selected={active}
              onClick={() => navigate({ search: { segment: slugify(b.segment_name) }, replace: true })}
              className={cn(
                "rounded-md border px-3 py-1.5 text-sm font-medium transition-colors",
                active
                  ? "border-primary bg-primary text-primary-foreground"
                  : "bg-card text-foreground hover:bg-accent hover:text-accent-foreground",
              )}
            >
              {b.segment_name}
            </button>
          );
        })}
      </div>

      <div className="panel mb-6 flex flex-col gap-4 p-5 sm:flex-row sm:items-center">
        <div className="flex items-center gap-3">
          <span className="size-3 rounded-full" style={{ background: chartColors[segIndex % 5] }} />
          <div>
            <h2 className="text-lg font-semibold">{brief.segment_name}</h2>
            {seg && <p className="text-sm text-muted-foreground">{seg.description.split(" Observed averages")[0]}</p>}
          </div>
        </div>
        {seg && (
          <div className="flex gap-6 sm:ml-auto">
            <MiniStat label="Customers" value={`${seg.customer_share_percent.toFixed(1)}%`} />
            <MiniStat label="Avg LTV" value={money(seg.average_predicted_ltv)} />
            <MiniStat label="Channel" value={channelLabel(brief.recommended_channel)} />
          </div>
        )}
      </div>

      <div className="grid gap-4 lg:grid-cols-3">
        <Block icon={<User className="size-4" />} title="Persona">{brief.persona}</Block>
        <Block icon={<Target className="size-4" />} title="Main pain">{brief.main_pain}</Block>
        <Block icon={<Zap className="size-4" />} title="Value proposition" highlight>{brief.value_proposition}</Block>
      </div>

      <div className="mt-4 grid gap-4 lg:grid-cols-3">
        <Panel className="lg:col-span-2" title="Message variants">
          <ol className="space-y-3">
            {brief.message_variants.map((m, i) => (
              <li key={m} className="flex gap-3 rounded-md bg-muted p-3 text-sm">
                <span className="num text-xs font-semibold text-muted-foreground">0{i + 1}</span>
                <span className="flex items-start gap-2">
                  <MessageSquareQuote className="mt-0.5 size-4 shrink-0 text-primary" />
                  {m}
                </span>
              </li>
            ))}
          </ol>
        </Panel>
        <div className="grid gap-4">
          <Block icon={<Megaphone className="size-4" />} title="Recommended channel" highlight>
            <span className="text-base font-semibold">{channelLabel(brief.recommended_channel)}</span>
          </Block>
          <Panel title="Likely objections">
            <ul className="space-y-2 text-sm">
              {brief.likely_objections.map((o) => (
                <li key={o} className="flex gap-2">
                  <ShieldQuestion className="mt-0.5 size-4 shrink-0 text-muted-foreground" />
                  {o}
                </li>
              ))}
            </ul>
          </Panel>
        </div>
      </div>

      <h2 className="mt-8 mb-3 flex items-center gap-2 text-sm font-semibold">
        <FlaskConical className="size-4 text-primary" /> A/B tests
      </h2>
      <div className="grid gap-4 md:grid-cols-2">
        {brief.ab_tests.map((t, i) => (
          <article key={t.hypothesis} className="panel p-5">
            <h3 className="font-semibold">{t.name ?? `Test ${i + 1}`}</h3>
            <p className="mt-1 text-sm text-muted-foreground">{t.hypothesis}</p>
            <div className="mt-4 grid grid-cols-2 gap-2 text-sm">
              <div className="rounded-md border p-3">
                <p className="eyebrow mb-1">Variant A</p>
                {t.variant_a}
              </div>
              <div className="rounded-md border p-3">
                <p className="eyebrow mb-1">Variant B</p>
                {t.variant_b}
              </div>
            </div>
            {t.primary_metric && (
              <p className="mt-3 text-xs text-muted-foreground">
                Primary metric: <span className="font-medium text-foreground">{t.primary_metric}</span>
              </p>
            )}
          </article>
        ))}
      </div>

      <p className="mt-8 text-xs text-muted-foreground">
        Source:{" "}
        {brief.source === "local_template" || briefsData.generated_without_external_api
          ? "deterministic local template (no external API call)"
          : (brief.source ?? "AI-generated")}
        .
        A strategic draft. Review with a marketer or PM before execution.
      </p>
    </>
  );
}

function Block({ icon, title, children, highlight }: { icon: ReactNode; title: string; children: ReactNode; highlight?: boolean }) {
  return (
    <section className={cn("panel p-5", highlight && "border-primary/30 bg-accent")}>
      <p className={cn("eyebrow mb-2 flex items-center gap-1.5", highlight && "text-accent-foreground")}>
        {icon} {title}
      </p>
      <div className="text-sm leading-relaxed">{children}</div>
    </section>
  );
}

function MiniStat({ label, value }: { label: string; value: string }) {
  return (
    <div>
      <p className="eyebrow">{label}</p>
      <p className="num mt-0.5 text-sm font-semibold">{value}</p>
    </div>
  );
}
