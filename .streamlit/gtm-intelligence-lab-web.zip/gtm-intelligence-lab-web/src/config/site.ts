// Public repository and profile links shown on the About page.
export const site = {
  name: "GTM Intelligence Lab",
  githubRepo: "https://github.com/castrocarolina/GTM-Intelligence-LAB-Project",
  githubProfile: "https://github.com/castrocarolina",
};
