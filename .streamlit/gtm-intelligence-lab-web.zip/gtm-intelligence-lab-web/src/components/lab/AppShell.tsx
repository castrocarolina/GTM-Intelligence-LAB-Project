import { Link } from "@tanstack/react-router";
import type { ReactNode } from "react";
import { BarChart3, FileText, FlaskConical, Info, SlidersHorizontal, Users } from "lucide-react";
import { site } from "@/config/site";

const nav = [
  { to: "/", label: "Overview", icon: BarChart3 },
  { to: "/segments", label: "Segments", icon: Users },
  { to: "/brief", label: "GTM Brief", icon: FileText },
  { to: "/simulator", label: "Simulator", icon: SlidersHorizontal },
  { to: "/about", label: "About", icon: Info },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  return (
    <div className="min-h-screen lg:grid lg:grid-cols-[232px_1fr]">
      <aside className="hidden lg:flex lg:flex-col bg-sidebar text-sidebar-foreground border-r border-sidebar-border sticky top-0 h-screen">
        <Brand />
        <nav className="flex flex-col gap-0.5 px-3 py-4">
          {nav.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              activeOptions={{ exact: item.to === "/" }}
              className="flex items-center gap-2.5 rounded-md px-3 py-2 text-sm transition-colors hover:bg-sidebar-accent hover:text-sidebar-accent-foreground data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-accent-foreground"
            >
              <item.icon className="size-4 opacity-80" />
              {item.label}
            </Link>
          ))}
        </nav>
        <div className="mt-auto px-6 py-5 text-xs leading-relaxed text-sidebar-foreground/60">
          Portfolio project. Spend data is simulated.
        </div>
      </aside>

      <div className="min-w-0">
        <header className="lg:hidden sticky top-0 z-20 bg-sidebar text-sidebar-foreground">
          <Brand />
          <nav className="flex gap-1 overflow-x-auto px-3 pb-3">
            {nav.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                activeOptions={{ exact: item.to === "/" }}
                className="shrink-0 rounded-md px-3 py-1.5 text-sm hover:bg-sidebar-accent data-[status=active]:bg-sidebar-accent data-[status=active]:text-sidebar-accent-foreground"
              >
                {item.label}
              </Link>
            ))}
          </nav>
        </header>
        <main className="mx-auto w-full max-w-6xl px-4 py-6 sm:px-6 lg:px-10 lg:py-10">
          {children}
        </main>
      </div>
    </div>
  );
}

function Brand() {
  return (
    <Link to="/" className="flex items-center gap-2.5 px-6 py-4 lg:py-6">
      <span className="grid size-7 place-items-center rounded-md bg-sidebar-primary text-sidebar-primary-foreground">
        <FlaskConical className="size-4" />
      </span>
      <span className="text-sm font-semibold tracking-tight text-sidebar-accent-foreground">
        {site.name}
      </span>
    </Link>
  );
}
