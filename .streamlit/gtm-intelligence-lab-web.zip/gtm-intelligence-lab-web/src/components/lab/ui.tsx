import type { ReactNode } from "react";
import { AlertTriangle } from "lucide-react";
import { cn } from "@/lib/utils";

export function PageHeader({
  eyebrow,
  title,
  description,
  actions,
}: {
  eyebrow?: string;
  title: string;
  description?: ReactNode;
  actions?: ReactNode;
}) {
  return (
    <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
      <div className="max-w-2xl">
        {eyebrow && <p className="eyebrow mb-2">{eyebrow}</p>}
        <h1 className="text-2xl font-semibold tracking-tight sm:text-3xl">{title}</h1>
        {description && <p className="mt-2 text-sm text-muted-foreground">{description}</p>}
      </div>
      {actions}
    </div>
  );
}

export function Panel({
  title,
  subtitle,
  children,
  className,
  right,
}: {
  title?: string;
  subtitle?: ReactNode;
  children: ReactNode;
  className?: string;
  right?: ReactNode;
}) {
  return (
    <section className={cn("panel p-5", className)}>
      {(title || right) && (
        <div className="mb-4 flex items-start justify-between gap-4">
          <div>
            {title && <h2 className="text-sm font-semibold">{title}</h2>}
            {subtitle && <p className="mt-0.5 text-xs text-muted-foreground">{subtitle}</p>}
          </div>
          {right}
        </div>
      )}
      {children}
    </section>
  );
}

export function SimulatedNotice({ children }: { children?: ReactNode }) {
  return (
    <div
      role="note"
      className="flex items-start gap-3 rounded-lg border border-warning/50 bg-warning-soft px-4 py-3 text-sm text-warning-foreground"
    >
      <AlertTriangle className="mt-0.5 size-4 shrink-0 text-warning" />
      <div>
        {children ?? (
          <>
            <strong className="font-semibold">Channel spend is simulated.</strong> CAC, ROAS and
            payback are planning estimates from a fixed-seed scenario, not real ad-platform data.
          </>
        )}
      </div>
    </div>
  );
}

export function SimBadge() {
  return (
    <span className="inline-flex items-center rounded-full border border-warning/50 bg-warning-soft px-2 py-0.5 text-[10px] font-semibold uppercase tracking-wide text-warning-foreground">
      Simulated
    </span>
  );
}

export function Kpi({
  label,
  value,
  hint,
  simulated,
}: {
  label: string;
  value: string;
  hint?: string;
  simulated?: boolean;
}) {
  return (
    <div className="panel p-5">
      <div className="flex items-center justify-between gap-2">
        <p className="eyebrow">{label}</p>
        {simulated && <SimBadge />}
      </div>
      <p className="num mt-3 text-2xl font-semibold sm:text-[1.7rem]">{value}</p>
      {hint && <p className="mt-1 text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export const chartColors = [
  "var(--chart-1)",
  "var(--chart-2)",
  "var(--chart-3)",
  "var(--chart-4)",
  "var(--chart-5)",
];

export const axisProps = {
  stroke: "var(--muted-foreground)",
  fontSize: 11,
  tickLine: false,
  axisLine: false,
} as const;

export function ChartTip({ lines }: { lines: { label: string; value: string }[]; }) {
  return (
    <div className="panel px-3 py-2 text-xs">
      {lines.map((l) => (
        <div key={l.label} className="flex justify-between gap-4">
          <span className="text-muted-foreground">{l.label}</span>
          <span className="num font-medium">{l.value}</span>
        </div>
      ))}
    </div>
  );
}
