import segmentsJson from "@/data/segments.json";
import kpisJson from "@/data/kpis.json";
import briefsJson from "@/data/briefs.json";
import simulatorJson from "@/data/simulator.json";

// Types mirror the Python `src.export_for_web` output. Optional fields keep the
// UI tolerant of small schema changes in future exports.

export type Segment = {
  name: string;
  description: string;
  customer_count: number;
  customer_share_percent: number;
  average_rfm: { recency_days: number; frequency_orders: number; monetary_revenue_per_order: number };
  historical_revenue: number;
  average_predicted_ltv: number;
  total_predicted_ltv: number;
};

export type ChannelKpi = {
  channel: string;
  spend: number;
  spend_is_simulated?: boolean;
  attributed_orders_simulated: number;
  attributed_new_customers_simulated?: number;
  cac: number;
  estimated_attributed_revenue: number;
  roas_estimated: number;
  payback_months_estimated: number;
};

export type Kpis = {
  currency: string;
  revenue_total: number;
  average_order_value: number;
  repeat_purchase_rate: number;
  cac_overall: number;
  roas_overall: number;
  payback_months_overall_estimated: number;
  gross_margin_assumption: number;
  marketing_spend_is_simulated: boolean;
  channel_attribution_is_simulated: boolean;
  channel_kpis: ChannelKpi[];
  limitations?: string;
};

export type AbTest = {
  name?: string;
  hypothesis: string;
  variant_a: string;
  variant_b: string;
  primary_metric?: string;
};

export type Brief = {
  segment_name: string;
  persona: string;
  main_pain: string;
  value_proposition: string;
  message_variants: string[];
  recommended_channel: string;
  likely_objections: string[];
  ab_tests: AbTest[];
  source?: string;
};

export type SimulatorConfig = {
  spend_is_simulated: boolean;
  causal_estimate: boolean;
  currency?: string;
  channel_efficiency_assumptions: Record<string, number>;
  segment_channel_affinity_assumptions: Record<string, Record<string, number>>;
  formula: Record<string, string>;
  formula_explanation: string;
  limitations: string[];
};

export const segmentsData = segmentsJson as {
  currency?: string;
  source_record_level_data_included?: boolean;
  k_selection?: { method: string; elbow_k?: number; selected_k: number; silhouette?: number };
  /** Registered customers with no orders; excluded from RFM clustering. */
  customers_without_orders?: number;
  segments: Segment[];
};
export const kpis = kpisJson as Kpis;
export const briefsData = briefsJson as { generated_without_external_api?: boolean; briefs: Brief[] };
export const simulator = simulatorJson as SimulatorConfig;

export const segments = segmentsData.segments;
export const briefs = briefsData.briefs;
/** Customers with at least one order (the segmented base). */
export const totalCustomers = segments.reduce((s, x) => s + x.customer_count, 0);
export const customersWithoutOrders = segmentsData.customers_without_orders ?? 0;
export const totalSpend = kpis.channel_kpis.reduce((s, c) => s + c.spend, 0);

const channelLabels: Record<string, string> = {
  search: "Search",
  social: "Social",
  email: "Email",
  affiliate: "Affiliate",
  brand: "Brand",
};

/** Display name for a channel key such as "search" -> "Search". */
export function channelLabel(key: string) {
  return channelLabels[key] ?? key.charAt(0).toUpperCase() + key.slice(1);
}

/** The exporter uses 9999 days / 0 orders as a sentinel for customers without a completed order. */
export function hasNoOrders(s: Segment) {
  return s.average_rfm.frequency_orders === 0 || s.average_rfm.recency_days >= 9999;
}

export function slugify(name: string) {
  return name
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/(^-|-$)/g, "");
}
