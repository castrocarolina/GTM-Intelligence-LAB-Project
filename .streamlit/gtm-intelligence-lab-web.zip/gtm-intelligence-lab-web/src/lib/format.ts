import { kpis } from "@/lib/data";

const currency = kpis.currency || "BRL";

export function money(value: number, opts: { compact?: boolean } = {}) {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    notation: opts.compact ? "compact" : "standard",
    maximumFractionDigits: opts.compact ? 1 : value < 1000 ? 2 : 0,
  }).format(value);
}

export function num(value: number, opts: { compact?: boolean; digits?: number } = {}) {
  return new Intl.NumberFormat("en-US", {
    notation: opts.compact ? "compact" : "standard",
    maximumFractionDigits: opts.digits ?? (opts.compact ? 1 : 0),
  }).format(value);
}

export function pct(value: number, digits = 1) {
  return `${(value * 100).toFixed(digits)}%`;
}

export function signedPct(value: number, digits = 1) {
  const s = (value * 100).toFixed(digits);
  return `${value > 0 ? "+" : ""}${s}%`;
}
