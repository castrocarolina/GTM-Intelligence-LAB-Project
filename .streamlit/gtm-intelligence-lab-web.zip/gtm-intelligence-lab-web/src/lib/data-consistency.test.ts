import { describe, expect, it } from "vitest";
import { kpis, segments, simulator, totalCustomers } from "@/lib/data";

// Guards against re-exports where channel numbers and overall numbers drift apart.
describe("exported data stays internally consistent", () => {
  const spend = kpis.channel_kpis.reduce((s, c) => s + c.spend, 0);

  it("channel revenue adds up to total revenue (within 1%)", () => {
    const channelRevenue = kpis.channel_kpis.reduce((s, c) => s + c.estimated_attributed_revenue, 0);
    expect(Math.abs(channelRevenue / kpis.revenue_total - 1)).toBeLessThan(0.01);
  });

  it("overall ROAS equals total revenue / total channel spend (within 1%)", () => {
    expect(Math.abs(kpis.roas_overall / (kpis.revenue_total / spend) - 1)).toBeLessThan(0.01);
  });

  it("new customers attributed to channels add up to the segmented customers", () => {
    const attributed = kpis.channel_kpis.reduce((s, c) => s + (c.attributed_new_customers_simulated ?? 0), 0);
    expect(attributed).toBe(totalCustomers);
  });

  it("every segment has simulator affinity assumptions and a unique name", () => {
    const names = segments.map((s) => s.name);
    expect(new Set(names).size).toBe(names.length);
    for (const n of names) expect(simulator.segment_channel_affinity_assumptions[n]).toBeDefined();
  });
});
