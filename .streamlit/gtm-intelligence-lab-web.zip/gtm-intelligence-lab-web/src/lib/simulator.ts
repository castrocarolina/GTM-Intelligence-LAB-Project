import type { Segment, SimulatorConfig } from "@/lib/data";

// Scaling constants from the exporter's formula block (simulator.json → formula).
export const REVENUE_SCALE = 0.35;
export const LTV_SCALE = 0.25;
export const MULTIPLIER_FLOOR = -0.5;

export type Move = {
  segment: string;
  source: string;
  target: string;
  /** Share of the source channel's budget to move, 0..1 */
  pct: number;
};

export type MoveResult = {
  amountMoved: number;
  budgets: { channel: string; before: number; after: number }[];
  revenueMultiplier: number;
  cappedMultiplier: number;
  revenueDelta: number;
  ltvDelta: number;
};

export function simulateMove(
  config: SimulatorConfig,
  segment: Segment,
  budgets: Record<string, number>,
  move: Move,
): MoveResult {
  const pct = Math.min(1, Math.max(0, move.pct));
  const eff = config.channel_efficiency_assumptions;
  const aff = config.segment_channel_affinity_assumptions[segment.name] ?? {};
  const same = move.source === move.target;

  const sourceBudget = budgets[move.source] ?? 0;
  const amountMoved = same ? 0 : sourceBudget * pct;

  const budgetsOut = Object.entries(budgets).map(([channel, before]) => ({
    channel,
    before,
    after:
      channel === move.source && !same
        ? before - amountMoved
        : channel === move.target && !same
          ? before + amountMoved
          : before,
  }));

  const tEff = eff[move.target] ?? 0;
  const sEff = eff[move.source] ?? 0;
  const revenueMultiplier = same ? 0 : tEff * (aff[move.target] ?? 0) - sEff * (aff[move.source] ?? 0);
  const cappedMultiplier = Math.max(revenueMultiplier, MULTIPLIER_FLOOR);
  const effectivePct = same ? 0 : pct;

  return {
    amountMoved,
    budgets: budgetsOut,
    revenueMultiplier,
    cappedMultiplier,
    revenueDelta: segment.historical_revenue * effectivePct * cappedMultiplier * REVENUE_SCALE,
    ltvDelta: segment.total_predicted_ltv * effectivePct * Math.max(tEff - sEff, 0) * LTV_SCALE,
  };
}
