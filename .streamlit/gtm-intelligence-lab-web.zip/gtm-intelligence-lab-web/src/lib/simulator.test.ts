import { describe, expect, it } from "vitest";
import type { Segment, SimulatorConfig } from "@/lib/data";
import { simulateMove } from "@/lib/simulator";

const config: SimulatorConfig = {
  spend_is_simulated: true,
  causal_estimate: false,
  channel_efficiency_assumptions: { search: 1.1, email: 1.35, affiliate: 0.9 },
  segment_channel_affinity_assumptions: {
    "Loyal High-Value": { search: 0.95, email: 1.3, affiliate: 0.8 },
  },
  formula: {},
  formula_explanation: "",
  limitations: [],
};

const loyal: Segment = {
  name: "Loyal High-Value",
  description: "",
  customer_count: 415,
  customer_share_percent: 92.22,
  average_rfm: { recency_days: 899.25, frequency_orders: 2.89, monetary_revenue_per_order: 420.14 },
  historical_revenue: 516347.66,
  average_predicted_ltv: 107.94,
  total_predicted_ltv: 44795.63,
};

const budgets = { search: 261821, email: 127408, affiliate: 138143 };

describe("budget simulator (exporter formula)", () => {
  it("moves source budget × % into the target and keeps the total fixed", () => {
    const r = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "search", target: "email", pct: 0.2 });
    expect(r.amountMoved).toBeCloseTo(52364.2, 6);
    const after = Object.fromEntries(r.budgets.map((b) => [b.channel, b.after]));
    expect(after["search"]).toBeCloseTo(209456.8, 6);
    expect(after["email"]).toBeCloseTo(179772.2, 6);
    const total = r.budgets.reduce((s, b) => s + b.after, 0);
    expect(total).toBeCloseTo(261821 + 127408 + 138143, 6);
  });

  it("estimates revenue as segment revenue × % × multiplier × 0.35", () => {
    const r = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "search", target: "email", pct: 0.2 });
    expect(r.revenueMultiplier).toBeCloseTo(0.71, 10);
    expect(r.revenueDelta).toBeCloseTo(25662.4787, 3);
  });

  it("caps a negative revenue multiplier at -0.5", () => {
    const r = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "email", target: "affiliate", pct: 0.2 });
    expect(r.revenueMultiplier).toBeCloseTo(-1.035, 10);
    expect(r.revenueDelta).toBeCloseTo(-18072.1681, 3);
  });

  it("only adds LTV when the target channel has higher base efficiency (× 0.25)", () => {
    const up = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "search", target: "email", pct: 0.2 });
    expect(up.ltvDelta).toBeCloseTo(559.9454, 3);
    const down = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "email", target: "affiliate", pct: 0.2 });
    expect(down.ltvDelta).toBe(0);
  });

  it("does nothing when source and target are the same channel", () => {
    const r = simulateMove(config, loyal, budgets, { segment: loyal.name, source: "email", target: "email", pct: 0.5 });
    expect(r.amountMoved).toBe(0);
    expect(r.revenueDelta).toBe(0);
  });
});
