# Correções de dados: GTM Intelligence Lab

Copie estes arquivos por cima dos que estão no seu projeto, mantendo as mesmas pastas.

## O que foi corrigido

1. **Recência (899 dias "recentes")**: `src/data/pipeline.py`
   A recência agora é contada a partir do dia seguinte ao último pedido do conjunto de dados (a data de corte padrão do RFM), e não a partir de hoje.
   Clientes sem nenhum pedido ficam com `recency_days` vazio e `has_orders = False`, em vez de receber o valor fictício 9999.

2. **Segmento "At Risk" vazio (35 clientes sem pedidos)**: `src/models/rfm_segmentation.py`
   Só clientes com pelo menos um pedido entram no K-means. O número de clientes excluídos fica em `selection["customers_without_orders"]`.
   Os nomes dos clusters agora são sempre únicos: antes, dois clusters podiam receber o nome "At Risk" e ser fundidos sem aviso.
   Resultado: K = 4 (silhueta 0,283), com os segmentos Loyal High-Value, Core / Growth, Occasional e At Risk. Todos têm premissas no simulador.

3. **Canais x total (ROAS 3,57× x 0,55×, payback de 242 meses)**: `src/data/synthetic_data.py` + `data/raw/marketing_spend_by_channel.csv`
   O gasto simulado cobria só 12 meses de 2023, enquanto os pedidos se estendem por 47 meses. Além disso, gerava 7.724 pedidos atribuídos para 1.200 pedidos reais.
   Agora o gasto cobre os mesmos 47 meses e o orçamento de cada mês é dimensionado pelos pedidos reais daquele mês (R$120 por pedido).
   Os pedidos reais e os clientes novos são distribuídos entre os canais pela participação no gasto, então os totais por canal somam exatamente 1.200 pedidos e 415 clientes.
   Um CSV novo foi incluído. Para recriá-lo a partir de `orders.csv`, rode: `python -m src.data.rebuild_spend`

4. **CAC**: `src/features/marketing_metrics.py`
   O CAC agora divide o gasto pelos clientes que compraram (415), e não por todos os cadastrados (450).

## Números depois da correção

| | Antes | Depois |
|---|---|---|
| Gasto simulado | R$930,8 mil | R$144,0 mil |
| ROAS geral | 0,55× | 3,59× |
| ROAS por canal | ~3,57× | 3,57×–3,66× |
| CAC geral / por canal | R$2.068 / ~R$120 | R$347 / R$333–R$357 |
| Payback geral / por canal | 242 / ~9,6 meses | 37,5 / 36,7–37,6 meses |

## Ajuste necessário no seu `src/export_for_web.py`

Esse arquivo não está no GitHub, então não consegui alterá-lo. Para ele gerar os mesmos números que o site mostra agora, faça três mudanças:

- **CAC por canal** = `spend / attributed_new_customers` (coluna nova no CSV), em vez de `spend / attributed_orders`.
  Exporte também `attributed_new_customers_simulated`.
- **Payback por canal** = `spend / (receita atribuída × margem / nº de meses com pedidos)`.
  É a mesma fórmula do payback geral.
- **Opcional, em `segments.json`**: exporte `customers_without_orders` e `k_selection`. O site já usa esses campos se existirem.
- **Opcional, em `simulator.json`**: exporte as afinidades só dos segmentos que existem nos dados.

## Testes

`tests/test_data_fixes.py` cobre as cinco correções. Rodei `python -m pytest tests -q` com 17 testes passando.
Eu não tinha o seu `tests/test_export_for_web.py`, então esses testes do exportador não estão nessa conta.

`changes.diff` mostra exatamente o que mudou em cada arquivo.
