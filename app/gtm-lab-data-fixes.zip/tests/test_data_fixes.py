"""Regression tests for the data-consistency fixes."""

from __future__ import annotations

import numpy as np
import pandas as pd

from src.data.pipeline import build_customer_base
from src.data.synthetic_data import simulate_marketing_spend
from src.features.marketing_metrics import calculate_business_summary
from src.models.rfm_segmentation import _name_clusters, prepare_rfm_features


def _orders() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "order_id": ["O1", "O2", "O3", "O4"],
            "customer_id": ["C1", "C1", "C2", "C3"],
            "order_purchase_timestamp": ["2024-01-02", "2024-03-12", "2024-01-09", "2024-02-20"],
            "order_value": [150.0, 250.0, 90.0, 120.0],
        }
    )


def _customers() -> pd.DataFrame:
    return pd.DataFrame(
        {"customer_id": ["C1", "C2", "C3", "C4"], "signup_date": ["2023-12-01"] * 4}
    )


def test_recency_is_measured_from_the_last_order_in_the_dataset_not_today() -> None:
    base = build_customer_base(_customers(), _orders()).set_index("customer_id")
    # Snapshot date = 2024-03-13 (day after the latest order).
    assert base.loc["C1", "recency_days"] == 1
    assert base.loc["C2", "recency_days"] == 64


def test_customers_without_orders_have_no_sentinel_and_are_not_clustered() -> None:
    base = build_customer_base(_customers(), _orders()).set_index("customer_id")
    assert not base.loc["C4", "has_orders"]
    assert pd.isna(base.loc["C4", "recency_days"])
    rfm = prepare_rfm_features(base.reset_index())
    assert "C4" not in set(rfm["customer_id"])
    assert rfm["recency_days"].max() < 9999


def test_cac_divides_spend_by_purchasing_customers() -> None:
    summary = calculate_business_summary(_orders(), pd.DataFrame({"spend": [300.0]}), customers=_customers())
    assert summary["acquired_customer_count"] == 3
    assert summary["cac"] == 100.0


def test_simulated_spend_matches_order_counts_and_period() -> None:
    orders = _orders()
    spend = simulate_marketing_spend(orders, rng=np.random.default_rng(1), cost_per_order=120)
    assert spend["attributed_orders"].sum() == len(orders)
    assert spend["attributed_new_customers"].sum() == orders["customer_id"].nunique()
    assert set(spend["month"]) == {"2024-01", "2024-02", "2024-03"}
    assert abs(spend["spend"].sum() - 4 * 120) < 0.1  # per-row rounding to cents


def test_cluster_names_are_unique() -> None:
    summary = pd.DataFrame(
        {
            "avg_recency": [565.0, 281.0, 740.0, 595.0],
            "avg_frequency": [4.99, 3.09, 1.90, 2.03],
            "avg_monetary": [480.0, 358.0, 325.0, 675.0],
        }
    )
    names = _name_clusters(summary)
    assert len(set(names.values())) == 4
    assert names[2] == "Occasional"
    assert names[3] == "At Risk"
