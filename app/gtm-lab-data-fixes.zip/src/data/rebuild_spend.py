"""Rebuild the simulated marketing spend file from the existing orders.

Usage: python -m src.data.rebuild_spend
"""

from __future__ import annotations

from pathlib import Path

from .synthetic_data import regenerate_marketing_spend

if __name__ == "__main__":
    spend = regenerate_marketing_spend(Path(__file__).resolve().parents[2])
    print(
        f"Rebuilt marketing_spend_by_channel.csv: {len(spend)} rows, "
        f"spend {spend['spend'].sum():,.2f}, attributed orders {int(spend['attributed_orders'].sum())}"
    )
